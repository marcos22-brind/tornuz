
# Torus Android (WebView)

Este projeto transforma o Torus Browser em um APK Android usando WebView.

## Estrutura

- Os arquivos HTML/JS estão na pasta `assets/`
- Um `WebViewActivity` pode ser usado para carregar `file:///android_asset/index.html`

## Como compilar

1. Abra no Android Studio
2. Use uma `WebView` no `MainActivity.kt` ou `MainActivity.java` com:
```kotlin
webView.loadUrl("file:///android_asset/index.html")
```
3. Ative permissões de internet se usar API externa
4. Compile o APK e teste no dispositivo

---

🔧 Pode ser integrado com Flutter, Kotlin, Java ou Cordova.
