
# Abyssal Chat

Um chat interativo com estilo dark (Abyssal), suporte a API online (Gemini) ou local (via túnel), com histórico salvo no navegador e suporte a vídeos por link.

## Funcionalidades

- Interface estilo abyssal/dark
- Conexão com API Gemini **ou local (offline)**
- Histórico salvo no `localStorage`
- Suporte a links de vídeo (YouTube/Vimeo/etc)
- Exportação de conversa
- Alternador de modo online/local
- Campo para colar a URL local da API

## Rodando localmente

```bash
npm install
npm run dev
```

## Requisitos

- Node.js 18+
- Navegador moderno

---

Criado para testes privados e uso offline.
